let arr = []; 
let a = prompt("ghi vài thứ bất kỳ: ")

arr.push(a)



if (arr.length < 3){
    arr.shift();
}   else{
    arr.pop(); 
    arr.pop();
}


console.log(arr)