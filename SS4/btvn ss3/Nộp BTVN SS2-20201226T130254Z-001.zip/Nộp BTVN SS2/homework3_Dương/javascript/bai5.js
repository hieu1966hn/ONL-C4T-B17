const input = document.getElementById("input")
const output = document.getElementById("output")

let products = []
let newproducts = []

let indexofArr1 = Number(prompt("Khởi tạo một mảng, nhập vào số phần tử của mảng thứ nhất(tối đa 10 phần tử)"))
for (i=0;i<indexofArr1;i++){
    products.push(prompt("Nhập vào phần tử thứ " + (i+1) + " của mảng"))
}
let indexofArr2 = Number(prompt("Khởi tạo một mảng, nhập vào số phần tử của mảng thứ hai(tối đa 10 phần tử)"))
for (i=0;i<indexofArr2;i++){
    newproducts.push(prompt("Nhập vào phần tử thứ " + (i+1) + " của mảng"))
}

input.innerText = "Input: Nhập vào 2 mảng là: " + "[" + products + "]"+" và " + "[" + newproducts + "]"

let result = products.concat(newproducts)
output.innerText = "Output: Kết hợp 2 mảng, ta được 1 mảng mới là: " + "[" + result + "]"

