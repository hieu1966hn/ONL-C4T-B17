const input = document.getElementById("input")
const output = document.getElementById("output")
var indexofArr = Number(prompt("Khởi tạo một mảng, nhập vào số phần tử của mảng(tối đa 10 phần tử"))
var Arr = []
var result
while ((indexofArr%1) !== 0|| indexofArr <0 || indexofArr > 10){
    indexofArr = Number(prompt("Lỗi, vui lòng nhập lại số phần tử của chuỗi mà bạn muốn khởi tạo"))
}
for (i=0;i<indexofArr;i++){
    Arr.push(prompt("Nhập vào phần tử thứ " + (i+1) + " của mảng"))
}
result = Arr.join(" - ")
input.innerText = "Input: " + "[" + Arr + "]"
output.innerText = "Output: " + result