let animal = []
let a = prompt ("give me  a array")

animal.push(a)


if (animal.length == 0){
    animal.push("cat","mouse")
}

if (animal.length == 1){
    animal.push("elephant")
}

if (animal.length == 2){
    animal.pop(1);
    animal.push("Monkey, Tiger")
}

console.log(animal)
