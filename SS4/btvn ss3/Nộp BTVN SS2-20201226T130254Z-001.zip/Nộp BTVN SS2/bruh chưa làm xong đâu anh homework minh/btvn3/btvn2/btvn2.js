let arr = []; 
let a = prompt("ghi vài thứ bất kỳ: ")
alert("vui long kiem tra console")

arr.push(a)

function arrayToString(input) {
    let result;

   result = input.join("-");

    return result;
}



 
console.log(arrayToString(arr));