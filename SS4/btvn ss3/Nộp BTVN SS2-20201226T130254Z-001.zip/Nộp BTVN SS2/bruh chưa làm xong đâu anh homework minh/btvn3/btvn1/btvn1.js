// let input 
// let the_array = []
// let ask
// let finish



// input = prompt("write a array, maximum is 10: ").toString();
// ask = prompt ("do you want to continue? ").toLowerCase();
// the_array.join()



// while (ask=="yes" || ask == "y"){

//     if (ask.length > 10){
//         break
//     }


 

//     if( ask == "yes" || ask == "y"){
//         input = prompt("write a array, maximum is 10: ").toString();
//         ask = prompt ("do you want to continue? ").toLowerCase();
//         the_array.push(input)

//     }
//     else if(ask == "no" || ask == "n"){
//         alert("Cac bien cua ban la: " , the_array );

//     }

//     else{
//         alert("Cac bien cua ban la: " , the_array );
//         break
//     }
    
// }



let arr = []; 
let a = prompt("ghi vài thứ bất kỳ: ")
alert("vui long kiem tra console")

arr.push(a)

function arrayToString(input) {
    let result;

   result = input.join("-");

    return result;
}



 
console.log(arrayToString(arr));




